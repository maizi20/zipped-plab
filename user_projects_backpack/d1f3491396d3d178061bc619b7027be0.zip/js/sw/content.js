//# sourceURL=/nlc/js/sw/content.js
//
define('Content',['API','LDB','lpromise','setting','crypto_js','proxy','workspace_reflect'],(API,LDB,P,setting,crypto,proxy,workspace_reflect)=>class{
  constructor(){
    // this.api=new API;
    this.ldb=new LDB;
      //()=>caches.match('loc/Users/GetUser.json').then(r=>r.json())
        //.then(o=>this.ldb.add('user',(o=o.body||o.Data,o.User.Statistic=o.Statistic,o.User)))
  }open($setting=setting){
    return this.ldb.open({
      name:$setting.current.local.db.name,version:1,
      stores:{
        experiment:[
          {n:'ID',k:'ID',u:!0}
          ,{n:'Category',k:'Category'}
          ,{n:'simple',k:['Category','CreationDate']}
          ,{n:'by_updated',k:['Category','UpdateDate']}
        ],
        user:[
          {n:'ID',k:'ID',u:!0}
          ,{n:'by_ver',k:['Verification']}
        ],
        workspace:[
          {n:'ID',k:'ID',u:!0}
        ],
        comment:[
          {n:'ID',k:'ID',u:!0},
          {n:'target',k:'TargetID'},
          {n:'where',k:['TargetID','Timestamp']}
        ],
        blob:[
          {n:'ID',k:'ID',u:!0}
          ,{n:'Category',k:'Category'}
          ,{n:'Name',k:'Name'}
        ],
        log:[
          {n:'ID',k:'ID',u:!0}
          ,{n:'name',k:'name'}
          ,{n:'time',k:'time'}
          ,{n:'all',k:['name','time']}
        ]
      }
    }).then(()=>this);
  }req(u,o,r,raw){
    return proxy.request({
      url:new URL(u,setting.current.api.url),body:JSON.stringify(o),
      headers:r.headers,method:r.method,signal:r.signal,referrerPolicy:r.referrerPolicy
    }).then(r=>raw?r:r.json().then(e=>{
      if(e&&e.Status<400)return e.Data;
      throw new Error(`req ${u} error: ${String(e.Messages).slice(0,32)} ${JSON.stringify(e.Data||null).slice(0,128)}`);
    }))
  }imports(init){
    return P.all([
      'comment','user','experiment','workspace','blob'
    ].map(
      n=>Array.isArray(init[n])&&this.ldb.every(n,init[n],{method:'put'})
    )).then(()=>this)
  }users_modifyinformation(o,r){
    // throw new Error('debug');
    return this.req('Users/ModifyInformation',o,r);
  // }users_authenticate(o,r){
  //   return this.req('Users/Authenticate',o,r,!0);
  }async users_getuser({ID},r){
    return!setting.current.local.disable&&await this.ldb.get('user',ID)||this.req('Users/GetUser',{ID},r)
    .then(o=>o&&(o.User.Statistic=o.Statistic,(o=o.User).updateTime=Date.now(),this.ldb.put('user',o)).then(()=>o))
    .then(o=>o&&{Statistic:o.Statistic,User:(delete o.Statistic,o)})
  }async contents_getsummary({Category,ContentID,Language,WithSummary},r){
    return!setting.current.local.disable&&await this.ldb.get('experiment',ContentID)||
    this.req('Contents/GetSummary',{Category,ContentID,Language,WithSummary},r)
    .then(o=>(o.updateTime=Date.now(),this.ldb.put('experiment',o).then(()=>o)))
  }contents_getprofile({ID},r){
    return this.req('Contents/GetProfile',{ID},r)
  }contents_getlibrary({Category,Language,Take,Skip}){
  }contents_getworkspace({ContentID}){
    return this.getWorkspace(ContentID);
  }async getComments({TargetID,TargetType,Take,Skip,CommentID},R){
      //s=await this.ldb.count('comment','target',TargetID)
    ;Take=Math.abs(Take)
    ;var a=await this.ldb.indexRange('comment','where',[[TargetID,TargetID],[0,Skip]],{direction:'prevunique'})
    ,c,o=[],t
    ;if(!a.length)
      return this.req('Messages/GetComments',{TargetID,TargetType,Take,Skip,CommentID},R).then(o=>(
        t=Date.now(),o.Comments.forEach(e=>e.updateTime=t),
        this.ldb.every('comment',o.Comments,{method:'put'}).then(()=>o)
      ))
    ;return{
      Comments:a,Target:null,Count:null
    }
  }messages_getcomments(init,R){
    return this.getComments(init,R)
  }async contents_localsearch({
    Category='Experiment',Key='Subject',Index='ID',
    Flags='',Content,Reg=!1,SkipChars=0,
    Take=200,Skip=0,LastKey,LastID,Width=8
  }){
    var c=this.ldb.indexRange(Category,Index,[Last||'',[]])
      ,re=Reg&&RegExp(Content,Flags);
    Skip?await c.skip(Skip):
      Last&&await c.seek(Last);
    return c.fold(v=>{
      re.lastIndex=SkipChars;
      for(var t=String(v[Key]),o=[],r;r=re.exec(t);)
        if(r=r.indices||r,o.push({range:r.slice(0),groups:r.groups})>=Width)break;
      if(o.length)return{
        Content:v,Ranges:o,ID:v.ID,
        Keys:[].concat(c.keyPath).map(k=>v[k])
      }
    })
  }pushLog({error,where,stack,comment}){
    
  }getLogs({Take,Skip,From,To,Name}){
    return this.ldb.indexRange('log','all')
  }async getWorkspace(ID,R){
    var r;
    if(r=await this.ldb.get('workspace',ID))
      return r;
    if(r=workspace_reflect.mapping.get(ID))return req(new Request(
      workspace_reflect.sources[r.s],{headers:{'range':'bytes='+(r.f|0)+'-'+(r.t?~-r.t:'')}}
    )).then(r=>r.json()).then(o=>(o.updateTime=Date.now(),o.ID||(o.ID=ID),this.ldb.put('workspace',o).then(()=>o)));
    return this.req('Contents/GetWorkspace',{ContentID:ID},R)
      .then(o=>(o.updateTime=Date.now(),o.ID||(o.ID=ID),this.ldb.put('workspace',o).then(()=>o)));
  }_getComments({TargetID,Skip,Take}){
    var c=this.ldb.indexRange('comments','by_timestamp',[
      [TargetID,TargetID],
      [0,Date.now()]
    ]);
    return c.skip(Skip).then(()=>c.take(Take))
  }queryComments(query){
    //{TargetID,UserID,Timestamp,Nickname,Verification,Skip,Take}
    var c=this.ldb.indexRange(
      'comments','query','TargetID,UserID,Timestamp,Nickname,Verification,Skip,Take'
      .split(',').map(k=>query[k])
    );
    return c.skip(Skip).then(()=>c.take(Take))
  }qswitch(id,c,d,l,p,m,u){
    return this.ldb.indexRange('experiment','simple',[c,d],{direction:'prevunique'});
    switch(~id&7){
      case 0b111:
        return this.ldb.indexRange('experiment','simple',[c,d,l],{direction:'prevunique'});
      case 0b000:
      case 0b001:
      case 0b011:
        return this.ldb.indexRange('experiment','by_pmu',[c,d,l,p,m,u],{direction:'prevunique'});
      case 0b100:
      case 0b101:
        return this.ldb.indexRange('experiment','by_mu',[c,d,l,m,u],{direction:'prevunique'});
      case 0b010:
      case 0b011:
        return this.ldb.indexRange('experiment','by_pu',[c,d,l,u],{direction:'prevunique'});
    }
  }contents_queryexperiments(init){
    var{
      Languages=[],ExcludeLanguages=[],Tags=[],ModelTags=[],ExcludeTags=[],
      Category='Experiment',ModelID,ParentID,UserID,Special,From,Skip=0,Take=20,Days=0,Sort=0,ShowAnnouncement
    }=init.Query,o,tid=
      !!ModelTags.length<<7|!!Languages.length<<6|!!ExcludeLanguages.length<<5|!!Tags.length<<4|!!ExcludeTags.length<<3|
      !!ParentID<<2|!!ModelID<<1|!!UserID
    ,any=[-1/0,[]],c=this.qswitch(
      tid,
      [Category,Category],[Days?Date.now()-Days*864e5:0,1/0],
      tid&4?[ParentID,ParentID]:any,
      tid&2?[ModelID,ModelID]:any,
      tid&1?[UserID,UserID]:any,
     {direction:'prevunique'});
    //pmu,mu,up
    //if(!(Take<0?Take=0:Take))return{$values:[]};
    Take=Math.floor(Math.abs(Take));
    Skip=Math.floor(Math.abs(Skip));
    if(!tid)
      return(From?c.seek(From):c.skip(Skip)).then(()=>c.take(Take)).then(o=>({$values:o}));
    return o=[],(From?c.seek(From):c.skip(0)).then(c=>c.fold((c,e)=>{
      if(e&&!e.result)
        return c.stop();
      var v=c.value;
      //实验数都没破千直接暴力筛选就好了，相信后人的智慧
      (~tid&4||v.ParentID===ParentID)&&
      (~tid&2||v.ModelID===ModelID)&&
      (~tid&1||v.User.ID===UserID)&&
      (~tid&64||~Languages.indexOf(v.Language))&&
      ExcludeLanguages.indexOf(v.Language)<0&&
      Tags.every(t=>v.Tags.indexOf(t)>=0)&&
      ExcludeTags.every(t=>v.Tags.indexOf(t)<0)&&
      ModelTags.every(t=>v.ModelTags.indexOf(t)>=0)&&
      (Skip?--Skip:o.push(v)===Take&&c.stop());
      return c.advance(1),c.request
    })).then(()=>({$values:o}))
  }
})
define('uint8array_to_wordarray',['crypto_js'],c=>u=>c);
define('online',(setting)=>()=>navigator.onLine);
define(
  'content',['Content','lpromise','img_cache','jszip','flat_json','crypto_js'],
  (C,P,img_cache,Zip,flat,crypto)=>fetch(new URL('/user_projects_backpack/0e2c4c236e2bcda47624d72acfb1a3c9.zip',scope))
  .then(r=>r.arrayBuffer()).then(b=>Zip.loadAsync(b))
  .then(async z=>{
    var h=Date.now()
    ,c=flat.parse(JSON.parse(await z.file('comment.json').async('text')))
    ,e=flat.parse(JSON.parse(await z.file('expriment.json').async('text')))
    // 看到这行注释记得提醒我把压缩包的命名错误改回来
    // 不改了，迟点整个重构
    ,d=(await z.file('description.csv').async('text')).split('\r').map((t,i)=>(
      t=new TextEncoder().encode(t),{ID:e[i].des=crypto.MD5(crypto.lib.WordArray.create(t)).toString(crypto.enc.Hex),body:t}
    ))
    ;c.forEach(e=>e.rt=h-e.Timestamp)
    ;console.log({h,c,e,d})
    ;return new C().open().then(n=>n.imports({comment:c,experiment:e,blob:d}))
  })
)
//Category:experiment,discussion,model,user,workspace,model_code,tutorial_code,localizations

