//# sourceURL=/nlc/js/sw/local.js
define('idb_req_warp',['lpromise'],P=>q=>new P((r,j)=>{
  var n;
  q instanceof IDBRequest?(
    n=e=>{
      q.removeEventListener('success',n),q.removeEventListener('error',n);
      e.type==='success'?r(q):j(e)
    },
    q.addEventListener('success',n),
    q.addEventListener('error',n)
  ):r(q)
}));
define('idb_range_cover',[],()=>(r,i)=>r instanceof IDBKeyRange||(
  i instanceof IDBIndex&&!i.multiEntry&&Array.isArray(i.keyPath)?
  IDBKeyRange.bound(r.map(e=>e[0]||-1/0),r.map(e=>e[1]||e[0]||['~']),!1,!1):
  Array.isArray(r)?IDBKeyRange.bound(r[0],r[1]):IDBKeyRange.only(r)
));
define('LDB',['lpromise','idb_req_warp','idb_range_cover'],(P,rwarp,irc)=>class LDB{
  open({name,version,stores,init}){
    return new P((r,j)=>{
      var req=indexedDB.open(name,version);
      req.onsuccess=e=>{
        this.db=req.result,r(this)
      };
      req.onupgradeneeded=e=>{
        console.log(e);
        this.db=req.result,this.init(stores)
      };req.onblock=req.onerror=j;
      setTimeout(j,5000,'timeout')
    });
  }init(stores){
    //debugger
    'function'!==typeof stores[Symbol.iterator]&&(stores=Object.entries(stores));
    var name,key,store,info,index,{db}=this,n,k,u,m;
    for([name,info]of stores){
      store=db.objectStoreNames.contains(name)?db.objectStore(name):db.createObjectStore(name,{keyPath:'ID'});
      'function'!==typeof info[Symbol.iterator]&&(info=Object.entries(info));
      for({n,k,u,m}of info){
        store.indexNames.contains(k)&&(
          !0//index=store.index(key),index.keyPath!==(info.k||info.keyPath)&&(store.deleteIndex(key),!1)
        )||store.createIndex(n||''+k,k,{unique:u||!1,multiEntry:m||!1});
      }
    }
  }count(name,index,range,options={}){
    var t=this.db.transaction(name),i=t.objectStore(name).index(index);
    return rwarp(i.count(irc(range,i))).then(e=>e.result);
  }match(name,index,range,options={}){
    var t=this.db.transaction(name),i=t.objectStore(name).index(index);
    return rwarp(i.getAll(irc(range,i),options.count||2147483647)).then(e=>e.result);
  }indexRange(name,index,range,options={}){
    var t=this.db.transaction(name),i=t.objectStore(name).index(index);
    range=irc(range,i);
    return new LDB.Cursor({req:i.openCursor(range,options.direction),range,tr:t})
  }get(name,key){
    var s=this.db.transaction(name).objectStore(name);
    return rwarp(s.get(key)).then(e=>e.result)
  }put(name,val){
    var s=this.db.transaction(name,'readwrite').objectStore(name);
    return rwarp(s.put(val)).then(e=>e.result)
  }add(name,val){
    var s=this.db.transaction(name,'readwrite').objectStore(name);
    return rwarp(s.add(val)).then(e=>e.result)
  }every(name,raws,{method,mode}){
    var s=this.db.transaction(name,mode||'readwrite').objectStore(name);
    return P.all(raws.map(val=>rwarp(s[method](val)).then(e=>e.result)));
  }
  static Cursor=class{
    constructor({req,range,tr}){
      this.ready=new P(r=>{
        this.req=req,this.range=range,this.tr=tr;
        req.onsuccess=e=>{
          req.onsuccess=null,this.cursor=req.result;
          tr||(tr=this.cursor.source,this.store=tr=tr.objectStore||tr,this.tr=tr=tr.transaction);
          r(this),this.ready.then=f=>new P(r=>r(f(this)))
        };
      })
    }skip(n){
      return n?this.flush().then(g=>(
        g.cursor.advance(n),rwarp(g.req).then(()=>g)
      )):P.resolve(this)
    }seekKey(k,i){
      return this.flush().then(g=>(
        g.cursor.continuePrimaryKey(k,i),rwarp(g.req).then(()=>g)
      ))
    }seek(k){
      return this.flush().then(g=>(
        g.cursor.continue(k),rwarp(g.req).then(()=>g)
      ))
    }take(n){
      return this.flush().then(async g=>{
        if(o=[],c=g.cursor)for(var o,c,r=g.req;o.push(c.value)<n&&r.result;)
          g.cursor.continue(),await rwarp(g.req);
        return o
      })
    }del(){
      return this.flush().then(g=>rwarp(g.cursor.delete(v)).then(()=>g))
    }put(v){
      return this.flush().then(g=>rwarp(g.cursor.update(v)).then(()=>g))
    }get(){
      return this.flush().then(g=>g.cursor.value)
    }set(v){
      return this.flush().then(g=>{
        switch(typeof v){
          case'object':
            return rwarp(v===null?g.cursor.delete():g.cursor.update())
              .then(()=>(g.cursor.continue(),rwarp(g.req))).then(()=>g);
          case'number':
            return g.cursor.advance(v),rwarp(g.req).then(()=>g);
          case'undefined':
            return g.cursor.continue(),rwarp(g.req).then(()=>g);
          default:
            return g.cursor.continue(v),rwarp(g.req).then(()=>g);
        }
      }),[].a(
        (g.result=v)===null?g.cursor.delete():
          v===void 0||g.cursor.update(v),g
      )
    }async fold(f,o){
      for(var g=await this.flush(),c=this.cursor,d=!0,e;d&&c;)
        c.stop=n=>d=!1,e=await rwarp(f(c,e));
    }async map(f){
      
    }flush(){
      return this.ready.then(g=>(g.tr.durability||(g.tr=g.tr.db.transaction(this.store.name)),g))
    }
  }
});
define('LocalBlob',['LDB'],(LDB)=>class LocalBlob{
  constructor(){
    
  }
})

