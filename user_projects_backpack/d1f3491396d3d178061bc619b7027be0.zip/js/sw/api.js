//# sourceURL=/nlc/js/sw/api.js
define('API',['lpromise','cors_req','setting','user'],(P,req,setting,login)=>class{
  constructor(){
    this.ac=new AbortController;
  }async asAnon(){
    this._user={}
  }xhr(o){
    return new P(f=>f(this.req(o))).then(r=>req(r)).then(r=>r.json()).then(r=>r.Data)
  }req(o){
    var u=this._user,h=new Headers(o.headers),url=new URL(o&&o.url||'/User/Authenticate',new URL(setting.current.api.url,location.origin));
    if(u)var{token,auth}=login.current;
    h.set('x-api-token',o.token||token),h.set('x-authcode',o.auth||auth);
    o.json!==void 0&&(o.body=JSON.stringify(o.json),h.set('content-type','text/json'));
    //o.json!==void 0&&(o.body=Response.json(o.json).body.pipeThrough(new CompressionStream('gzip')),h.set('content-type','gzipped/json'),h.set('accept-encoding','gzip'));
    return{
      url,headers:h,method:o.method||'POST',
      signal:o.signal||this.ac.signal,
      body:o.body||null
    }
  }homepage(){
    return this.cors({url:this.api_origin+'/Users'}).then(r=>r.json()).then(r=>r.Data)
  }ws(ContentID,Language='Chinese'){
    return this.xhr({
      url:'Contents/GetWorkspace',
      json:{ContentID,Language}
    })
  }getUser(ID){
    return this.xhr({
      url:'Users/GetUser',json:{ID},
    })
  }getSummary(Category,ContentID,){
    return this.xhr({
      url:'Contents/GetSummary',json:{
        Category,ContentID,
        Languages:["Chinese"]
      }
    })
  }getComments({TargetID,TargetType,Take,Skip,CommentID}){
    return this.xhr({
      url:'Messages/GetComments',
      json:{TargetID,TargetType,Take,Skip,CommentID}
    })
  }userProject(ID){
    return this.xhr({
      url:'Contents/GetProfile',json:{ID}
    })
  }query(Query){
    return this.xhr({
      url:'Contents/QueryExperiments',
      json:{Query}
    })
  }
});
