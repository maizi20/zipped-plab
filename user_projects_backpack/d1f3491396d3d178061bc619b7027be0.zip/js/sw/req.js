//# sourceURL=/nlc/js/sw/req.js
define('img_padding',[],()=>Object.create(null));
define('try_clone',[],()=>o=>o);
define('logs',['try_clone'],(try_clone)=>new class Logs{
  async log(error,level,type,extra){
    return~-this.raw.push(try_clone({
      level,type,extra,error,stack:new Error('trace_log').stack
      //,stack:error.stack,name:error.name
    }))
  }async query({Match=[],Skip=0,Take=20}){
    //var o=[],m='function'===typeof Match[Symbol.iterator]?[...Match]:Object.entries(Match);
    return{
      Skip,Take,Count:this.raw.length,
      Result:try_clone(this.raw.slice(Skip,Skip+Take)).map(n=>(delete n.extra,n))
    }
  }async item(id){
    return try_clone(this.raw[id])
  }raw=[]
});
define('img_req',['img_padding','img_cache'],(m,c)=>async r=>
  m[r]&&m[r].clone()||await c.match(r)||
  await fetch(r,{referrerPolicy:'no-referrer',mode:'no-cors'}).then(
    n=>(m[r]=n.clone(),c.put(r,n.clone()).then(()=>delete m[r]),n)
    ,e=>Response.redirect(new URL('assets/img/error.png',scope))
  )
)
    //e=>(console.error(e),Response.redirect(`assets/img/${'user'===p[1]?'anon.png':'error.png'}`))
define(
  'req',['content','proxy','local','temp','img_cache','img_req','setting','logs','package','polyfill']
  ,(content,proxy,local,temp,img_cache,img_req,setting,logs,package)=>async function _req(R,e){
  var u=new URL(R.url,location),r,c=0,p;
  await done;
  if(u.href.startsWith('https://zhishi.oss-cn-beijing.aliyuncs.com/user_projects_backpack/'))
    return fetch(R);
  if(u.origin===location.origin){
    p=u.pathname.slice(scope.pathname.length).split('/');
    if(R.mode==='navigate')switch(p[0]){
      case'query':
      case'user':
      case'experiment':
      case'discussion':
      case'model':
      case'workspace':
      case'img':
        return local.match(new URL('page/format/frame.html',scope));
      case'index.html':
        return Response.redirect(new URL('page/main/index.html',scope));
      case'unload':
        return registration.unregister().then(()=>Response.json({code:200}))
        // return new Response(`<h5 style="color:red" onclick="navigator.serviceWorker.ready.then(w=>confirm('unload')&&w.unregister())">unload</h5>`,{headers:{
        //   'content-type':'text/html'
        // }});
      case'clearall':
        await caches.keys().then(a=>Promise.all(a.map(k=>caches.delete(k))));
        await indexedDB.databases().then(a=>Promise.all(a.map(e=>new Promise((r,j)=>{
          var q=indexedDB.deleteDatabase(e.name);q.onsuccess=r,q.onerror=q.onblocked=j
        }))));
        return Response.json({code:200});
      case'netlogoweb.org':
        if(p[1]==='content')
          return await package.netlogoweb_org.ready,local.match(new URL('netlogoweb.org/frame.html',scope)).then(r=>r.text()).then(
            t=>content.getWorkspace(u.searchParams.get('ID')).then(
              o=>new Response(t.replace('{placeholder}',o.ModelCode),{
                headers:{'content-type':'text/html'}
              })
            )
          );
    };
    switch(p[0]){
      case'img':
        if(setting.current.debug)return Response.redirect(new URL('assets/img/error.png',scope));
        switch(p[1]){
          case'user':
            return img_req(''+new URL(`users/avatars/${p[2].slice(0,4)}/${p[2].slice(4,6)}/${p[2].slice(6,8)}/${p[2].slice(8)}/${p[3]}.jpg!full`,setting.current.img.url));
          case'experiment':
            return img_req(''+new URL(`experiments/images/${p[2].slice(0,4)}/${p[2].slice(4,6)}/${p[2].slice(6,8)}/${p[2].slice(8)}/${p[3]}.jpg!full`,setting.current.img.url));
          case'texture':
            return texture_cache.match(u.href)
            return Response.redirect(new URL('assets/img/unity_richtext.png',scope));
          default:
            return Response.redirect(new URL('assets/img/error.png',scope));
        };break;
      case'api':
        if(p[1]==='Users'&&p[2]==='Authenticate')
          return proxy.request(Object.defineProperty(R,'url',{
            configurable:!0,value:new URL('Users/Authenticate',setting.current.api.url)
          }));
        return R.clone().json().then(o=>content[p[1].toLowerCase()+(p[2]?'_'+p[2].toLowerCase():'')]?.(o,R)||p[1].toLowerCase()+(p[2]?'_'+p[2].toLowerCase():'')).then(
          o=>Response.json({code:'200',status:200,body:o}),
          e=>logs.log(e,4,'content api').then(()=>Response.json({code:'500',status:500,body:e,msg:'api error'}))
        );
      case'page':
        if(p[1]==='info'){
          if(p[2]==='setting.json'){
            return'PUT'===R.method?R.json().then(
              o=>local.put(u.pathname,Response.json(Object.assets(setting,o))).then(()=>setting)
              ,e=>e
            ).then(e=>Response.json(
              e===setting?{code:'200',status:200,msg:'suc',body:e}:{code:400,status:400,msg:'faild',body:e}
            )):Response.json({code:'200',static:200,msg:'',body:null})
          }
        };break;
      case'log':
        switch(p[1]){
          case'query':
            return logs.query(Object.fromEntries(u.searchParams)).then(o=>Response.json(o));
          case'view':
            return logs.item(p[2]).then(o=>Response.json(o));
          case'flat':
            return logs.item(p[2]).then(o=>new Response(JSON.stringify(o,void 0,2),{
              headers:{'content-type':'text/plain ;charset=uft8'}
            }));
        };break;
      case'proxy':
        switch(p[1]){
          case'list':
            return Response.json(proxy.list());
          case'working':
          default:
            return proxy.workingList(u.searchParams.get('t')||2000).then(o=>Response.json(o));
        }
    }
    if(R.method==='PUT')return local.put(R.url,new Response(R.body)).then(()=>Response.json({code:'200',status:200,msg:'',body:null}));
  };
  if(r=await temp.match(R,{ignoreSearch:!0}))return r;
  if(r=await img_cache.match(R))return r;
  if(r=await local.match(R,{ignoreSearch:!0}))return r;
  if('/'===u.pathname.slice(-1)){
    if(r=await local.match(u.origin+u.pathname+'index.html'))return r;
  };
  switch(u.hostname){
    case'netlogo-cn.oss-cn-hongkong.aliyuncs.com':
    case'physics-lab.oss-cn-hongkong.aliyuncs.com':
    case'netlogo-static-cn.turtlesim.com':
    case'physics-static-cn.turtlesim.com':
      if(setting.current.debug)return Response.redirect(new URL('assets/img/error.png',scope));
      return img_req(R.url);
    case'site.fake':
      return Response.json({code:'200',status:200,msg:'test',body:null});
    default:
      if(proxy.includes(u))
        return proxy.request(R,e);
      if(u.hostname.endsWith('.turtlesim.com')
         ||u.hostname.endsWith('.aliyuncs.com')
         ||u.hostname.endsWith('.github.io')
         ||u.hostname.endsWith('.github.io')
      )if(r=await fetch(R),r.ok)return r;
  }
  return'navigate'===R.mode?local.match(new URL('page/format/404.html',scope)):Response.json({code:'404',status:404})
});
AMD.require(['req','temp','logs'],(q,temp,logs)=>self.req=(r,e)=>q(r,e).then(
  n=>n
    // r.mode==='navigate'&&~(n.headers.get('content-type')||'').indexOf('text/html')?
    // r.url.indexOf('?debug')<0?n:n.text().then(t=>new Response(t.replace('</head>',`<script>import("/p01.js").then(()=>'function'===typeof VConsole?new VConsole:AMD.require([AMD.current],V=>new V))</script></head>`),n)):
    // n//(n.headers.get('content-disposition')||'inline')!=='inline'?n:
    // temp.put('/tmp/view',n.clone()).then(()=>new Response(`<script defer src="${new URL('/js/main/view.js',scope)}"></script>`,{}))
  ,e=>logs.log(e,3,'uncatched req',{}).then(i=>Response.json({code:'500',status:500,msg:'sw_error',body:{view:new URL('log/view/'+i,scope),id:i,e:e&&e.stack||e+''}},{status:500}))
))
