//# sourceURL=/nlc/js/sw/main.js
define('main',['local','logs'],async(c,logs)=>{
  onunhandledrejection=async e=>
    logs.log(e.reason,5,'reject',{}).then(id=>errorPort.postMessage(e&&e.reason&&{
      action:'showError',id,
      stack:e.reason.stack,name:e.reason.name,
      trace:new Error('trace').stack
    }))
  await c.match(new URL('page/format/index.html',scope)).then(r=>c.put(new URL('page/main/index.html',scope),r));
  c.put(new URL('page/main/_index.html',scope),Response.redirect(new URL('page/readme_cn/index.html',scope)));
  // await c.match(new URL('page/format/init.html',scope)).then(r=>c.put(new URL('index.html',scope),r));
  //for(let k in ref)AMD.define(k,[],()=>s(ref[k]));
});
//AMD.import(['jszip','json5'],n=>fetch(new URL('js/lib/'+n+'.min.js',scope)).then(r=>r.text()).then(eval))
define('package',['local','jszip'],(c,Z)=>{
  return{
    netlogoweb_org:{
      ready:fetch(
         'https://zhishi.oss-cn-beijing.aliyuncs.com/user_projects_backpack/2a48a927fbe7abdff8d953b6e4465f89.zip'
        ,{headers:{'range':'bytes=0-1386538'}}
      ).then(r=>r.arrayBuffer()).then(b=>Z.loadAsync(b)).then(
        z=>Promise.all(Object.entries(z.files).map(({0:p,1:f})=>f.async('uint8array').then(
          b=>f.dir&&!b.length||c.put(p=new URL(p,scope),new Response(b,{headers:{
            'content-type':f.comment,
            'content-length':b.length,
            'last-modified':f.date.toUTCString(),
            'location':p.href,
            'x-hash-crc32':f.crc32||''
          }}))
        )))
      )
    }
  }
})
