//# sourceURL=/nlc/js/sw/proxy.js
define('Proxy',[],()=>class{
  constructor(){
    this.ports=new Map,this.tid=-1,this.requestPool=[console.error]
  }main(p){
    var n=Date.now();
    p.forEach((o,k)=>{
      if(n-o.time>2e4)
        p.delete(k),o.port.postMessage({action:'port_close'}),o.port.close();
      else if(n-o.time>9e3)
        o.port.postMessage({action:'ping'});
    })
  }async request(R,e){
    var u=new URL(R.url),p=this.ports.get(u.origin);
    if(p=p&&await p.ready)
      return p.fetch(R,e);
    throw new Error(`port not connect: ${u.origin}.`);
  }includes(h){
    return this.ports.has(new URL(h,scope).origin)
  }list(){
    return[...this.ports.keys()]
  }workingList({timeout}){
    return Promise.all([...this.ports].map(([p,o])=>new Promise(r=>{
      var n=setTimeout(e=>{
        r({origin:p,timeout}),o.port.removeEventListener('message',m)
      },timeout),m=e=>{
        clearTimeout(n),r({origin:p,ping:Date.now()-t})
      },t=Date.now();
      o.port.addEventListener('message',m,{once:!0});
    })));
  }connect(m){
    var p,u=new URL(m.url,scope);this.tid<0&&(this.tid=setInterval(this.main,2e3,this.ports));
    p=this.ports.get(u.origin),p&&p.flush&&p.flush(m);
    this.ports.set(u.origin,p={url:u,port:m.port,time:Date.now()});
    return p.ready=new Promise(re=>{
      p.port.onmessage=e=>{
        p.port.onmessage=e=>{
          var m=e.data;
          if(m)switch(m.action){
            case'ping':
              m.action='pong',p.port.postMessage(m,m.tr||[]);
            case'pong':
              p.time=Date.now();break;
            case'res':
              this.requestPool[m.pong](new Response(m.body,m)),delete this.requestPool[m.pong];break;
            case'err':
              this.requestPool[m.pong]({then(f,c){c(m.error)}}),delete this.requestPool[m.pong];break;
          }
        };re(p);
        if((e=e.data).action==='ping')
          e.action='pong',p.port.postMessage(e,e.tr||[]);
      };p.fetch=R=>new Promise((re,rj)=>{
        var{url,body,cache,credentials,headers,integrity,keepalive,method,mode,redirect,referrer,referrerPolicy,signal}=R
        ,ping=~-this.requestPool.push(re),tr=[],n=0,m;
        headers=[...new Headers(headers)],R.method!=='HEAD'&&R.method!=='GET'||(body=null);
        signal&&signal.addEventListener('abort',e=>p.port.postMessage({action:'abort',ping}),{once:!0});
        p.port.addEventListener('message',m=e=>{clearTimeout(n)},{once:!0});
        n=setTimeout(()=>{
          p.port.removeEventListener('message',m);
          p.port.postMessage({action:'abort',ping});
          re({then(r,j){j(new Error('not connect'))}})
        },2e3);
        url+='';
        new Promise(r=>r(body instanceof ReadableStream?new Response(body).arrayBuffer():body)).then(
          body=>p.port.postMessage({action:'req',ping,tr,url,body,cache,credentials,headers,integrity,keepalive,method,mode,redirect,referrer,referrerPolicy},tr),rj
        )
      });p.port.postMessage({action:'ping'})
    });
  }
})
define('proxy',['Proxy'],c=>new c)
define('cors_req',['proxy'],p=>R=>p.request(R));//p.request(r))
