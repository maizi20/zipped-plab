AMD.define('API',['req','lpromise','lzstring','flat_json','setting','login'],(req,P,lz,flat,setting,login)=>class API{
  constructor(){
    this.ac=new AbortController;
    this.img_cache=new Map;
    this._users={}
  }xhr(o){
    return new P(f=>f(this.req(o))).then(r=>req(r)).then(r=>r.json()).then(r=>{
      if(r.status<400||r.code<400)return r.Data||r.body||null;
      setting.current.debug&&console.log((r.body||r.msg).stack);
      throw new Error(r.code+' '+r.msg+'\n',{cause:r});
    })
  }req(o){
    var u=this._users,h=new Headers(o.headers),url=new URL('../../api/'+o.url,location)
    //,new URL(setting.current.api.url,location.origin));
    if(u.current)var{Token,AuthCode}=u.current;
    h.set('x-api-token',o.token||Token),h.set('x-authcode',o.authcode||AuthCode);
    o.json!==void 0&&(o.body=JSON.stringify(o.json),h.set('content-type','text/json'));
    //o.json!==void 0&&(o.body=Response.json(o.json).body.pipeThrough(new CompressionStream('gzip')),h.set('content-type','gzipped/json'),h.set('accept-encoding','gzip'));
    return{
      url,headers:h,method:o.method||'POST',
      signal:o.signal||this.ac.signal,
      body:o.body||null
    }
  }tryLogin(o){
    this._users.current=o;
    return this.xhr({
      url:'Users/ModifyInformation',json:{"Field":"Signature","Target":(Date.now()/1000|0).toString(16)}
    }).catch(e=>{}).then(e=>e||this.login(o)).catch(e=>{}).then(()=>this)
  }async login(o){
    this._users.current=null;
    return req(this.req({
      url:'Users/Authenticate',
      body:JSON.stringify({
        Login:o.Login,Password:o.Password,Version:1301,Statistic:null,
        Device:{
          ID:null,Platform:"Web",
          Timezone:"Local",Language:"Chinese",
          Identifier:"7db01528cf13e2199e141c402d79190e"
        }
      }),method:'POST'
    })).then(r=>r.json()).then(o=>{
      var{
        Token,AuthCode,Data:{
          User:{
            ID,Nickname,Signature,Verification,Avatar
          },User,Statistic:{LastLanguage}
          //,DeviceToken,Password,Statistic:{PushToken,LastLogin,LastDeviceID,LastLanguage}
        }
      }=o
      return this._users.current=this._users[ID]={
        User,Token,AuthCode,ID,Nickname,LastLanguage
        //Meta:{DeviceToken,Password,PushToken,LastLogin,LastDeviceID,LastLanguage}
      }
    });
  }async asAnon(){
    if(localStorage.anon)
      this.user=JSON.parse(localStorage.anon);
    else this.login({}).then(o=>{this.user=u,localStorage.anon=JSON.stringify(u)})
  }ws(ContentID,Language='Chinese'){
    return this.xhr({
      url:'Contents/GetWorkspace',
      json:{ContentID,Language}
    })
  }user(ID){
    return this.xhr({
      url:'Users/GetUser',json:{ID},
    })
  }localSearch(json){
    return this.xhr({url:'Contents/LocalSearch',json})
  }ply({TargetID,TargetType,Take,Skip,CommentID}){
    return this.xhr({
      url:'Messages/GetComments',
      json:{TargetID,TargetType,Take,Skip,CommentID}
    })
  }userProject(ID){
    return this.xhr({
      url:'Contents/GetProfile',json:{ID}
    })
  }query(Query){
    return this.xhr({
      url:'Contents/QueryExperiments',
      json:{Query}
    })
  }img_ref(cat,id,a){
    return new P(r=>{
      r('../../img/'+cat+'/'+id+'/'+a);
    });
  }
});
