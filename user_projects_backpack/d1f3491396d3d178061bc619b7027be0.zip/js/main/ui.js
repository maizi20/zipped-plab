//# sourceURL=/nlc/js/main/ui.js
AMD.define('ui',['promise','api','lzstring','setting'],(P,ngapi,LZString,setting)=>{
  function ce(n,c){
    var e=document.createElement(n);
    return c&&(e.classList=c),e
  }
  function timeout_recall(recall,timeout){
    if(!timeout)return recall(),()=>{};
    var id=setTimeout(()=>{id=0,recall(!0)},timeout);
    return()=>{id&&(clearTimeout(id),recall(!1))}
  }
  class Block{
    constructor(c){
      var e=ce('div',c);
      e.$handler=this,this.outter=this.inner=e,this.clist=e.classList
    }add(c){
      return this.outter.appendChild(c),this
    }remove(){
      return this.outter.remove(),this
    }
  }
  class Root extends Block{
    constructor(){
      if(root)return root;
      root=super();
      var e=document.getElementById('root');
      e?this.outter=e:document.body.appendChild(this.outter).id='root';
      this.add((this.desktop=new Desktop(this)).outter);
      this.add((this.Windows=new Block('ui-windows')).outter);
      this.add((this.messageBox=new MessageBox(this)).outter);
      //e.addEventListener('click',e=>Win.index||=Win.open().goto('home:'))
    }
  }
  class Bar extends Block{
    constructor({title,fn,target,edit}){
      super('bar');
      var t=this.title=ce('span','title')
        ,tools=this.tools=ce('div','tools');
      t.innerText=title,this.target=target;
      this.add(t).add(tools);
      fn&&fn.forEach(n=>this.newFn(n));
      if(edit){
        var s=0;
        t.contentEditable='plaintext-only';
        t.addEventListener('keydown',e=>{
          switch(e.code){
            case'Enter':
              e.preventDefault();
              edit.finish&&edit.finish(this,e);break;
            case'Escape':
              edit.cancel&&edit.cancel(this,e);break;
            case'Backspace':
            case'Delete':
              !t.innerText.length&&edit.cancel&&edit.cancel(this,e);break;
          }
        });
        //t.addEventListener('blur',e=>edit.cancel&&edit.cancel(this,e));
      }
    }newFn(n){
      var c=ce('div','tools-function');
      //c.style.backgroundImage=n.iron;
      c.innerText=n.text;
      n.click&&c.addEventListener('click',e=>n.disable||new P(r=>{
        n.disable=!0,c.classList.add('disable'),r(n.click(this.target,e))
      }).finally(()=>{n.disable=!1,c.classList.remove('disable')}));
      this.tools.appendChild(c);
    }
  }
  class Win extends Block{
    constructor({title,fn=WinBarFuncArray,rect,mode='flex'}={}){
      super('ui-window'),this.clist.add('mode-'+mode);
      var e=this.outter,s=e.style,a=new AbortController;
      this.abort=a.abort.bind(a),this.signal=a.signal;
      this.rect=(
          rect||=Win.currentWin?Win.currentWin.rect.slice(0):[0,0,800,600],
          rect[0]+=64,rect[1]+=64,rect
      );
      this.bar=new Bar({
        title,fn,target:this,edit:{
          //change:()=>{},interval
          finish:b=>this.goto(b.title.innerText),
          cancel:b=>b.title.innerText=decodeURIComponent(this.href)
        }
      });
      this.inner=ce('div','inner');//new Inner();
      this.add(this.bar.outter)
        .add(this.inner);
      this.bar.win=this;
      this.resetAni=()=>{};
      //rect[0]<0?s.right=-rect[0]:s.left=+rect[0];
      //rect[1]<0?s.bottom=-rect[1]:s.top=+rect[1];
      [s.top,s.left,s.width,s.height]=rect.map(n=>n+'px');
      this.updateRect();
      this.outter.addEventListener('click',e=>this.action(),{passive:!0});
    }static open(init,ele=root.outter){
      var w=new Win(init);
      ele.appendChild(w.outter);
      w.clist.add('hidden');
      return w.show().then(()=>w.action()),w;
    }action(){
      Win.currentWin&&Win.currentWin.clist.remove('action');
      (Win.currentWin=this).clist.add('action');
      //this.outter.remove();
      //root.outter.appendChild(this.outter);
    }close(){
      return new P(re=>{
        this.resetAni();
        this.clist.add('enable-ani');
        this.resetAni=timeout_recall(c=>{
          this.clist.add('close');
          this.resetAni=timeout_recall(c=>{
            this.clist.remove('enable-ani');
            this.outter.remove(),this.outter=this.bar=this.inner=null;
            this.resetAni=()=>{},re()
          },c&&150)
        },50)
      })
    }hide(){
      return new P(re=>{
        this.resetAni();
        this.clist.add('enable-ani');
        this.resetAni=timeout_recall(c=>{
          this.clist.add('hidden');
          this.resetAni=timeout_recall(c=>{
            this.clist.remove('enable-ani'),this.resetAni=()=>{},re()
          },c&&150)
        },50)
      })
    }show(){
      return new P(re=>{
        this.resetAni();
        this.clist.add('enable-ani');
        this.resetAni=timeout_recall(c=>{
          this.clist.remove('hidden');
          this.resetAni=timeout_recall(c=>{
            this.clist.remove('enable-ani'),this.resetAni=()=>{},re()
          },c&&150)
        },50)
      })
    }freeMove(){
      return new P(re=>{
        this.resetAni();
        document.addEventListener('mousedown',e=>{
          var{rect}=this,a=e=>{
            rect[0]+=e.movementX|0;
            rect[1]+=e.movementY|0;
            this.updateRect();
          },b=e=>{
            e.stopPropagation(),e.stopImmediatePropagation(),e.preventDefault(),this.resetAni()
          };this.resetAni();this.resetAni=()=>{
            this.resetAni=()=>{},
            document.removeEventListener('mousemove',a);
            document.removeEventListener('mouseup',b);
            re();
          };
          document.addEventListener('mousemove',a);
          document.addEventListener('mouseup',b);
          e.stopPropagation(),e.stopImmediatePropagation(),e.preventDefault()
        },{once:!0})
      });
    }freeResize(){
      return new P(re=>{
        this.resetAni();
        document.addEventListener('mousedown',e=>{
          var{rect}=this,a=e=>{
            rect[2]+=e.movementX|0;
            rect[3]+=e.movementY|0;
            this.updateRect();
          },b=e=>{
            e.stopPropagation(),e.stopImmediatePropagation(),e.preventDefault(),this.resetAni()
          };this.resetAni();this.resetAni=()=>{
            this.resetAni=()=>{},
            document.removeEventListener('mousemove',a);
            document.removeEventListener('mouseup',b);
            re();
          };
          document.addEventListener('mousemove',a);
          document.addEventListener('mouseup',b);
          e.stopPropagation(),e.stopImmediatePropagation(),e.preventDefault()
        },{once:!0})
      });
    }moveTo(x,y){
      var{rect}=this,s=this.outter.style;
      x===(x=+x)&&(rect[0]=x);
      y===(y=+y)&&(rect[1]=y);
      return this.updateRect(),this
    }resizeTo(w,h){
      var{rect}=this,s=this.outter.style;
      w===(w=+w)&&(rect[2]=w);
      h===(h=+h)&&(rect[3]=h);
      return this.updateRect(),this
    }moveBy(x,y){
      var e=this.outter;
      return this.moveTo(+x+e.offsetX,+y+e.offsetY),this
    }resizeBy(w,h){
      var e=this.outter;
      return this.resizeTo(+w+e.offsetWidth,+h+e.offsetHeight),this
    }updateRect(){
      var{rect}=this,e=this.outter,s=e.style;
      [s.left,s.top,s.width,s.height]=rect.map(n=>n+'px')
      //this.debugRect.innerText=`(${e.offsetX|0},${e.offsetY|0})${e.offsetWidth|0}x${e.offsetHeight|0}`
    }static showError(e){
      
    }goto(href){
      if(href.indexOf('{scope}')>=0)
        href.replace('{scope}',new URL('../../',location));
      if(href.startsWith('../../'))
        href=href.slice(6).replace('/',':');
      this.inner.remove();
      this.inner=ce('div','inner');//new Inner;
      this.add(this.inner);
      this.href=href instanceof URL?href:href=new URL(href,location);
      this.bar.title.innerText=decodeURIComponent(href.href);
      var c=0;
      switch(href.protocol.toLowerCase()){
        case'https:':
          switch(href.hostname){
            case'turtlesim.com':
              if(href.pathname==='/tuc/')if(href.search.startsWith('?chinese-'))
                return this.goto(href.search.slice(9).replace('-',':'));
              break;
            default:
              if(/\/(?:user|discussion|experiment|model)/i.test(href.pathname))
                return this.goto(href.pathname.replace(/^.+?\/(user|discussion|experiment|model)(s?)(?:\/(.*))?$/i,'$1$2:$3')+href.search);
              break;
           }
        case'models:':++c;
        case'discussions:':++c;
        case'experiments:':
          for(var block=new ExpList,q={
            Category:{d:'Discussion',e:'Experiment',m:'Model'}[href.protocol[0].toLowerCase()],
            Sort:1,//Languages:['Chinese'],
          },c=decodeURIComponent(href.pathname).split('/'),i=0,l=c.length,k,v;i<l;)
            k=c[i++],v=c[i++],q[k]=k[~-k.length]==='s'&&k!=='Days'?v.split(',').filter(n=>n):+v||v;
          this.inner.appendChild(block.outter);
          return ngapi.xhr({
            url:'Contents/QueryExperiments',
            json:{Query:q},signal:this.signal
          }).then(d=>block.update(d.$values)).then(()=>this);
        case'model:':++c;
        case'discussion:':++c;
        case'experiment:':
          block=new ExpInfo;
          this.inner.appendChild(block.outter);
          return ngapi.xhr({
            url:'Contents/GetSummary',
            json:{
              ContentID:block.ID=href.pathname.slice(0,24),
              Category:block.Category=['Experiment','Discussion','Model'][c],
              WithSummary:!0,Language:'Chinese'
            },signal:this.signal
          }).then(d=>block.update(d)).then(()=>this);
        case'people:':
          block=new UserInfo;
          this.inner.appendChild(block.outter);
          return ngapi.xhr({
            url:'Contents/GetProfile',
            json:{ID:href.pathname.slice(0,24)},
            signal:this.signal
          });
        case'profile:':
        case'social:':
          break;
        case'user:':
          block=new UserInfo;
          this.inner.appendChild(block.outter);
          return ngapi.user(href.pathname.split('/',1)[0]).then(d=>block.update(d)).then(()=>this);
        case'workspace:':
          return new Workspace().goto(href.pathname).then(()=>this);
      };return new P(r=>r(this))
      /*
/Activities/
/Discussion/60afc4056b081b0001e45cb6/Information/
/Discussions/
/Discussions/Languages/Chinese/
/Experiment/66910d00af793e159d7d17d1/Information/
/Experiments/Local/
/Experiments/Tags/算法/
/Model/60db8db3cf26af00017f5202/Information/
/People/60dc6b7104a1226aa18c6482/Discussions/
/Profile/Account/
/Profile/Information/
/Social/Notifications/
/User/60b772bf98c28f75a8305ec5/Profile/
/Workspace/
/Workspace/6687ebd7af793e159d7d1499/
/Workspace/Local/

*/
    }
  }
  class Inner extends Block{
    constructor(){
      super('inner')
    }update(block){
      return this.outter.innerText=JSON.stringify(block,void 0,2),this
    }
  }
  class Content extends Block{
    constructor(c){
      super(c),this.clist.add('ui-content')
    }
  }
  class List extends Content{
    constructor(c){
      super(c),this.clist.add('list')
    }
  }
  class ExpList extends List{
    constructor({name,data,mode='card'}={}){
      super('explist'),this.clist.add('mode-'+mode);
      this.mode=mode,data&&this.update(data)
    }update(block,{index}={}){
      this.data=block;
      return block.forEach((s,i)=>{
        this.add(new ExpItem().update(s,{index:index+i}).outter)
      }),this
    }
  }
  class CommentTable extends List{
    constructor({name,data,mode='card',lastTime=0}={}){
      super('comment-table');
      this.commentMap=new Map;
      var h,f;
      this.add(h=ce('div','head'));
      this.add(this.raw=ce('div','body'));
      h.append(
        f=ce('span','fetch'),
        this.counter=ce('span','counter'),
        this.datetime=ce('input','datetime'),
        this.title=ce('span','title')
      );
      f.innerText='fetch',this.datetime.placeholder='指定一个最晚评论时间';
      //this.datetime.type='datetime-local';
      f.addEventListener('click',e=>this.fetch({skip:Date.parse(this.datetime.value)}));
      this.datetime.addEventListener('keydown',e=>e.code==='Enter'&&this.fetch({skip:Date.parse(this.datetime.value)}))
      // h.appendChild((this.bar=new Bar({
      //   title:new Date().toLocaleString(),target:this,fn:[
      //     {text:'flush',click:t=>this.fetch()}
      //   ]
      // })).outter)
      this.ranges=new Ranges;
      this.mode=mode,data&&this.update(data),this.count=0/0;
    }fetch({range,skip,take=8}){
      skip=+skip||range&&+range.to||Date.now();
      return ngapi.ply({
        TargetID:this.ID,TargetType:this.Category,Skip:skip,Take:take,
      }).then(d=>this.update(d,{skip,range,take}))
    }where({Category,ID}){
      this.Category=Category,this.ID=ID
    }update(block,{range,index,skip,take}={}){
      this.counter.innerText=this.count=block.Count;
      var r=range||this.ranges.add(skip||block.Comments[0].Timestamp);
      this.ranges.grow(r,block.Comments);
      return this.flush(r),this;
    }flush(r){
      for(;r!==(r=r.self););
      if(!r.block){
        let b=r.block=new CommentArray({target:this,range:r}).update(r),lt=r.lt;
        lt&&lt.block?this.raw.insertBefore(b.outter,lt.block.outter||null):this.raw.appendChild(b.outter);
      }else{
        r.block.update(r)
      }
    }
  }
  class CommentArray extends List{
    constructor({target,range}={}){
      super('comment-array');
      this.raw=[],this.map=new Map,this.target=target,this.range=range;
      var h,br,bf;
      this.add((this.bar=new Bar({
        target,fn:[
          {text:'flush',click:t=>t.fetch({range:this.range})},
          {text:'reduce',click:t=>{this.clist.toggle('reduce'),this.outter.scrollIntoView()}},
          {text:'top',click:t=>{t.outter.scrollTo(0,0)}},
        ]
      })).outter)
      .add(this.body=ce('div','body'))
    }update(data){
      for(var{body:b,target:{commentMap:m},raw:r}=this,{list}=data,i=0,g,n;g=list[i++];)
        (n=m.get(g.ID))?n.target!==this&&(n.target=this,b.appendChild(n.outter)):(m.set(g.ID,n=new Comment({target:this}).update(g)),b.appendChild(n.outter));
      return this.range=data,this.bar.title.innerText=new Date(data.from).toLocaleString()+' - '+new Date(data.to).toLocaleString(),this
    }
  }
  class Ranges{
    constructor(){
      this.gt=null
    }add(from){
      for(var g,gt=this,lt;lt=gt,gt=gt.gt;)
        if(gt.from>from)break;//return g={from,to:from,list:[],gt,lt,block:new CommentArray},g.self=g,gt.lt=lt.gt=g;
      return g={from,to:from,list:[],gt,lt},gt&&(gt.lt=g),g.self=lt.gt=g;
    }grow(range,data){
      for(;range!==(range=range.self););
      range.list=this.concat(range.list,data,Array(range.list.length+data.length),0);
      var g=data[data.length-1].Timestamp;
      range.to<g||(range.to=g);
      if((g=range.lt).from>range.to)
        range.list=this.concat(range.list,g.list),range.to<g.to&&(range.to=g.to),g.self=range,g.block.remove(),(range.lt=g.lt).gt=range;
      return range
    }concat(a,b,o=[],g=0){
      for(var c=0,d=0,m=a[c++],n=b[d++];m&&n;)
        m.Timestamp>n.Timestamp?(o[g++]=m,m=a[c++]):(o[g++]=n,m.ID===n.ID&&(m=a[c++]),n=b[d++]);
      if(m)for(;o[g++]=m,m=a[c++];);
      else for(;o[g++]=n,n=b[d++];);
      return o.length=g,o
    }*[Symbol.iterator](){
      for(var g=this;g=g.gt;)yield g;
    }
  }
  class ExpInfo extends Content{
    constructor(){
      super('expinfo');
      this.add((
        this.body=new TagTable({cacheMode:'remove'})
          .addTable({text:'摘要',index:'index',block:new JSONView})
          .addTable({text:'简介',index:'des',block:new RichTextBox})
          .addTable({text:'源码',index:'source',block:new JSONView})
          .addTable({
            text:'评论',index:'comment',block:new CommentTable({mode:'flat'}),
            load:b=>b.block.ID?(b.load=()=>{},b.block.fetch({})):b.block.title.innerText='作品未加载,请稍后再试'
          })
          .addTable({text:'实验',index:'ws',block:new WsInfo})
          .addTable({text:'关联信息',index:'link',block:new List})
          .addTable({text:'更多',index:'more',block:new Content,hidden:!0})
          .select('index')
      ).outter);
      this.workspace=null,this.summary=null
    }where({ID,Category}){
      this.ID=ID,this.Category=Category
    }update(data){
      var{source,des,index,comment,ws,submit}=this.body.tags;
      index.block.update({
        标签:data.Tags,责任编辑:data.Editor&&(data.Editor.Nickname+'('+data.Editor.ID+')'),
        合作者:data.Coauthors,简介长度:data.Description&&data.Description.reduce((n,d)=>+d.length+n,0),
        类别:data.Category
      });
      //submit.block.update(data);
      comment.block.where({Category:data.Category,ID:data.ID});
      ws.load=b=>ngapi.ws(this.ID).then(d=>b.block.update(d));
      source.block.update(data);
      des.block.update(data.Description?data.Description.join('\n'):'loading');
    }updateWorkspace(ws){
      return P.resolve(this.body.tags.ws.block.update(ws)).then(()=>this)
    }
  }
  class WsInfo extends Content{
    constructor(){
      super('wsinfo');
      this.add((
        this.body=new TagTable({cacheMode:'remove'})
          .addTable({text:'摘要',index:'index',block:new JSONView})
          .addTable({
            text:'运行',index:'exec',block:new Launcher,
          })
          .addTable({text:'代码',index:'mc',block:new NLView})
          .addTable({text:'教程',index:'tc',block:new JSONView,hidden:!0})
          .addTable({text:'教程内嵌',index:'tcn',block:new NLView,hidden:!0})
          .addTable({text:'世界状态',index:'wsc',block:new TextView,hidden:!0})
          .addTable({text:'工作空间',index:'ws',block:new JSONView})
          .addTable({text:'Web',index:'web',block:new JSONView,hide:!0})
          .addTable({text:'翻译附件',index:'lc',block:new TextView,hidden:!0})
          .select('index')
      ).outter);
      this.workspace=null,this.summary=null
    }update(d){
      this.data=d;
      var t=this.body.tags,tc=JSON.parse(d.TutorialCode),w=JSON.parse(d.Workspace)
      ,s=LZString.decompressFromBase64(w&&w.WorldState||'')
      ,tcn=''
      ,inf=w&&w.Interfaces
      ,lc=d.Localizations;
      if(tc&&Array.isArray(tc.Sections))try{
        tcn=tc.Sections.map((s,sid)=>(s.Initializer?'\n;;---Section #'+sid+' '+s.Name+'\n'+s.Initializer:'\n')+(Array.isArray(s.Handlers)?s.Handlers.map(h=>h.Callback?';;----Handler '+h.Category+' '+h.Type+' '+h.Name+'\n'+h.Callback:'').join(''):'')).join('')
      }catch(e){};
      t.index.block.update(d);
      t.mc.block.update(d.ModelCode);
      t.exec.block.update(d);
      t.tc.block.update(tc);
      tc?(
        this.body.show('tc'),t.tc.block.update(tc)
        ,tcn?(this.body.show('tcn'),t.tcn.block.update(tcn)):this.body.hide('tcn')
      ):this.body.hide('tc');
      s?(this.body.show('wsc'),t.wsc.block.update(s)):this.body.hide('wsc');
      t.ws.block.update(w);
      lc?(this.body.show('lc'),t.lc.block.update(d.Localizations)):this.body.hide('lc');
      if(inf){
        inf.Web?(this.body.show('web'),t.web.block.update(inf.Web)):this.body.hide('web');
      }
      return P.resolve(this);
    }
  }
  class UserInfo extends Content{
    constructor(){
      super('userinfo');
      this.add((
        this.body=new TagTable({cacheMode:'remove'})
          .addTable({text:'摘要',index:'index',block:new UserItem})
          //.addTable({text:'封面',index:'bg',block:new ExpItem})
          .addTable({text:'源码',index:'source',block:new JSONView})
          .addTable({text:'主页',index:'comment',block:new CommentTable({mode:'flat'})})
          .addTable({text:'作品',index:'project',block:new UserProject})
          .addTable({text:'粉丝',index:'fans',block:new Unfinished('用户列表')})
          .addTable({text:'关注',index:'fw',block:new Unfinished('用户列表')})
          .select('index')
      ).outter);
    }update(data){
      var{Statistic,Comments,User}=data;
      this.body.tags.comment.load=b=>(b.load=()=>{},b.block.fetch({}));
      this.body.tags.project.load=b=>(b.load=()=>{},b.block.fetch({}));
      //this.body.tags.project.load=b=>(b.load=()=>{},ngapi.userProject(this.ID).then(d=>b.update()));
      this.ID=User.ID;
      this.body.tags.comment.block.where({Category:'User',ID:User.ID});
      this.body.tags.project.block.where({Category:'User',ID:User.ID});
      this.body.tags.index.block.update(data);
      //this.body.tags.bg.block.update(Statistic.Cover);
      this.body.tags.source.block.update(data);
      Comments&&this.body.tags.comment.block.update(Comments);
      return this;
    }
  }
  class UserItem extends Content{
    constructor(){
      super('useritem');
      var a=this.avatar=new Background,o=this.nodes={},c=this.cit=new ExpItem;
      'main,top,ext,sign,ext,name,id,level,lv,exp,maxexp,count,star,fire,fwr,fwg,gold,fiamond,fragment'.split(',').forEach(k=>o[k]=ce('div',k));
      this.outter.append(
        a.outter,o.main,c.outter
      ),o.main.append(
        o.top,o.sign,o.ext
      ),o.top.append(
        o.name,o.id,o.level
      ),o.level.append(
        o.lv,o.lvp=ce('progress','lvp'),
        o.exp,o.maxexp
      ),o.ext.append(
        o.count,o.star,o.fire,
        o.fwr,o.fwg,
        o.gold,o.fiamond,o.fragment
      )
    }update(data){
      var{Statistic:s,User:u}=data,o=this.nodes;
      o.sign.innerText=u.Signature;
      o.name.innerText=u.Nickname,o.id.innerText=u.UserID||u.ID;
      o.lv.innerText=u.Level;
      o.lvp.value=o.exp.innerText=u.Experience;
      o.lvp.max=o.maxexp.innerText=(a=>a*(a+1)*100)(+u.Level);
      o.lvp.position<1?o.lvp.classList.remove('full'):o.lvp.classList.add('full');
      o.count.innerText=s.ExperimentCount;
      o.star.innerText=s.StarCount;
      
      o.fire.innerText=u.Prestige;
      o.gold.innerText=u.Gold;
      o.fiamond.innerText=u.Diamond;
      o.fragment.innerText=u.Fragment;
      o.fwg.innerText=s.FollowingCount;
      o.fwr.innerText=s.FollowerCount;
      this.cit.update(s.Cover);
        /*
    "Verification": "Editor",
    "Avatar": 6,
    "AvatarRegion": 0,
    "Decoration": 0,
    "Subscription": 1,
    "SubscriptionUntil": "2030-01-01T00:00:00+00:00",
    "IsBinded": true,*/
      ngapi.img_ref('user',u.ID,u.Avatar).then(u=>this.avatar.use(u));
      //`/users/avatars/${u.ID.replace(/(....)(..)(..)(.+)/,'$1/$2/$3/$4')}/${u.Avatar}.jpg!block`
      return this;
    }
  }
  class UserProject extends Content{
    constructor(){
      super('user-project');
      this.add(this.body=ce('div','inner'));
    }update(o){
      var k,a,e;
      for(k in o){
        e=ce('div','project-box'),a=new ExpList,a.update(o[k]);
        this.body.appendChild(e);
        e.append(e=ce('div','title'),a.outter);
        e.innerText=k;
      }
    }fetch(){
      ngapi.userProject(this.ID).then(d=>this.update(d.Experiments))
    }where({ID}){
      this.ID=ID
    }
  }
  class Item extends Block{
    constructor(c){
      super(c),this.clist.add('item')
    }
  }
  class TagTable extends Content{
    constructor(init={}){
      super('tagtable');
      this.tags=[];this.selectIndex=-1;
      this.add(this.bar=ce('div','bar'))
        .add(this.inner=ce('div','inner'))
      this.bar.appendChild(this.list=ce('ul','list'));
      this.cacheMode=init.cacheMode;
    }addTables(object){
      return Object.keys(object).forEach(o=>{
        var o=object[k];o.index||(o.index=k);
        this.addTable(o)
      }),this
    }addTable(o){
      //tag,block,text,load
      var t=o.tag||(o.tag=ce('li','tag'));
      o.index!=null?this.tags[o.index]=o:o.index=~-this.tags.push(o);
      t.innerText=o.text;
      t.addEventListener('click',e=>this.select(o));
      this.list.appendChild(t);
      'remove'===this.cacheMode||this.inner.appendChild(o.block.outter);
      o.hidden&&t.classList.add('hidden');
      return this
    }select(b){
      var o='object'===typeof b?b:this.tags[b],g;
      if(this.selectIndex!==-1&&(g=this.tags[this.selectIndex])){
        g.tag.classList.remove('select');
        g.block.clist.remove('select');
        'remove'===this.cacheMode&&g.block.outter.remove();
      }
      this.selectIndex=o.index,o.tag.classList.add('select');
      try{
        o.load&&(o.ready=o.load(o))&&o.ready.then&&(
          o.tag.classList.add('loading'),o.ready.then(()=>o.tag.classList.remove('loading'))//,e=>(consoleo.tag.classList.add('loadfaild'))
        );
      }finally{
        o.block.clist.add('select');
        'remove'===this.cacheMode&&this.inner.appendChild(o.block.outter);
      }
      return this
    }hide(b){
      var o='object'===typeof b?b:this.tags[b];
      o.hidden=!1,o.tag.classList.add('hidden');
    }show(b){
      var o='object'===typeof b?b:this.tags[b];
      o.hidden=!0,o.tag.classList.remove('hidden');
    }
  }
  class Comment extends Item{
    constructor({target}){
      super(),this.clist.add('comment');
      this.target=target;
      var body,head;
      this.add((this.avatar=new Background()).outter)
        .add(body=ce('div','body'))
      body.appendChild(head=ce('div','header'));
      body.appendChild((this.content=new RichTextBox).outter);
      head.appendChild(this.username=ce('span','username'));
      head.appendChild(this.date=ce('span','date'));
      this.avatar.outter.addEventListener('click',e=>Win.open().goto('../../user/'+this.data.UserID))
    }update(data,{index}={}){
      this.data=data;
      this.username.innerText=data.Nickname;
      this.date.innerText=new Date(data.Timestamp).toLocaleString();
      ngapi.img_ref('user',data.UserID,data.Avatar).then(u=>this.avatar.use(u))
        //`/users/avatars/${data.UserID.replace(/(....)(..)(..)(.+)/,'$1/$2/$3/$4')}/${data.Avatar}.jpg!tiny.round`
      this.content.update(data.Content);
      return this
    }
  }
  class ExpItem extends Item{
    constructor({mode='card'}={}){
      super(),this.clist.add('expitem')
      var idx=ce('div','index');
      idx.appendChild(this.note=ce('span','note')),idx.appendChild(this.date=ce('span','date'));
      (this.bg=new Background).clist.add('bg');
      this.add(idx)
        .add(this.bg.outter)
        .add(this.title=ce('p','title'))
        .add(this.user=ce('div','user'));
      (this.avatar=new Background).clist.add('avatar');
      this.user.appendChild(this.avatar.outter);
      this.user.appendChild(this.userName=ce('span','username'));
      this.bg.outter.addEventListener('click',e=>{
        Win.open().goto('../../'+this.data.Category.toLowerCase()+'/'+this.data.ID)
      });
      this.user.addEventListener('click',e=>Win.open().goto('../../user/'+this.data.User.ID))
    }update(s,{index}={}){
      this.data=s;
      this.userName.innerText=s.User.Nickname;
      this.title.innerText=s.Subject||s.ModelName||s.LocalizedSubject&&s.LocalizedSubject.Chinese||s.LocalizedSubject.English;
      this.date.innerText=new Date(s.UpdateDate).toLocaleString();
      'object'===typeof index?(this.note.innerText=index,this.note.classList.remove('hide')):this.note.classList.add('hide');
      this.bg.use('../../assets/img/loading.svg');
      s.Image>=0&&ngapi.img_ref(s.Category.toLowerCase(),s.ID,s.Image).then(u=>this.bg.use(u));
      //`/${s.Category.toLowerCase()}s/images/${s.ID.replace(/(....)(..)(..)(.+)/,'$1/$2/$3/$4')}/${s.Image}.jpg!block`
      if(s.User)
      this.avatar.use('../../assets/img/anon.png'),
      s.User.Avatar>=0&&ngapi.img_ref('user',s.User.ID,s.User.Avatar).then(u=>this.avatar.use(u));
      //`/users/avatars/${s.User.ID.replace(/(....)(..)(..)(.+)/,'$1/$2/$3/$4')}/${s.User.Avatar}.jpg!tiny.round`
      return this
    }
  }
  class Background extends Block{
    constructor(c){
      super(c),this.clist.add('ui-background'),this.outter.innerText=' ';
    }use(u){
      return this.outter.style.backgroundImage=`url(${u})`,this
      //return ngapi.img_ref(u).then(u=>(this.outter.style.backgroundImage=`url(${u})`,this))
    }
  }
  class Img extends Block{
    constructor({width,height,class:c}={}){
      super(c),this.clist.add('imgframe');
      this.add(this.img=new Image(width,height));
    }use(u){
      return this.outter.style.backgroundImage=`url(${u})`,this
    }
  }
  class RichTextBox extends Content{
    constructor({options}={}){
      super('ui-unity-richtext-box');
      this.clist.add('ui-quad-box');
      this.add(this.body=ce('div','root'));
    }update(text){
      return new P(re=>{
        this.body.innerText='';
        var root=this.body.appendChild(ce('span','unity-richtext'))
        ,g=this.main(text,root)
        ,next=n=>{
          n.done?re(n.value):P.resolve(n.value).then(r=>next(g.next(r)))
        }
        next(g.next())
      }).then(()=>this)
    }*main(text,root){
      var W=/\W/g,quad=/quad/yi
      ,out=root,n,i=0,p,t=0,j=0,tag,stack=[out],l=text.length,value
      ,onclick=e=>{
        var t=e.target,s={}.toString;
        for(;t!==null&&'[object HTMLAnchorElement]'!==s.call(t);)t=t.parentElement;
        if(t)switch(t.protocol.toLowerCase()){
          case'file:':case'http:':case'https:':
          case'models:':case'discussions:':case'experiments:':
          case'model:':case'discussion:':case'experiment:':
          case'people:':case'profile:':case'social:':
          case'user:':case'workspace:':
            Win.open().goto(t.href);
                //stopPropagation,stopImmediatePropagation
          default:
          case'javascript:':case'data:':case'blob:':case'about:':
            e.preventDefault(),e.stopPropagation();
            break;
        }
      }
      for(;i=text.indexOf('<',j)+1;){
        n=ce('span','text'),n.innerText=text.slice(j&&j+1,i-1),out.appendChild(n);
        j=text.indexOf('>',i),W.lastIndex=i,t=W.exec(text).index|0;
        if(t===i+4&&(quad.lastIndex=i,quad.test(text))){
          value={size:30,width:1,height:1,x:0,y:0,color:'#777'};
          text.slice(t+1,j).split(/ +/g).forEach(t=>{
            t=t.split('=',2),value[t[0]]=t[1];
          });
          n=ce('span','quad'),n.$val=text.slice(t+1,j),out.appendChild(n),n=n.style;
          // n.height=value.size+'px';n.width=value.size/value.height*value.width+'px';
          // value.color&&(n.backgroundColor=value.color);
          // n.maskSize=value.width*100+'% '+value.height*100+'%';
          // n.maskPosition=value.x*100+'% '+value.y*100+'%';
        }else if(text[t]==='/'){
          out=stack.pop()
        }else{
          tag=text.slice(i,t).toLowerCase();
          text[t]==='='?value=text.slice(t+1,j):value=null;
          switch(tag){
            case'crypto':
              n=ce('span',tag),n.$val=value;break;
            case'support':
            case'nosupport':
              n=ce('span',tag),n.classList.add('fn-'+value);break;
            case'a':case'b':case'i':
              n=ce('span',tag);break;
            case'color':
              n=ce('span',tag),n.style.color=value;break;
            case'size':
              n=ce('span',tag),n.style.fontSize=value+'px';break;
            case'user':case'model':case'discussion':case'experiment':
              n=ce('a',tag),n.target='_blank',n.$val=value,n.href='../../'+tag+'/'+value;break;
            case'models':case'discussions':case'experiments':
              n=ce('a',tag),n.target='_blank',n.$val=value,n.href='../../query/'+tag+'?q='+value;break;
            case'trigger':case'help':case'run':
            case'observer':case'patches':case'turtles':case'links':
              n=ce('a',tag),n.$val=value,n.href='javascript:void(0)';break;
            default:
              n=ce('span','unknown')
          }
          stack.push(out),out.appendChild(n),out=n;
        }
      }
      n=ce('span','text'),n.innerText=text.slice(j&&j+1),root.appendChild(n);
      root.addEventListener('click',onclick);
      return root
    }
  }
  class TextView extends Content{
    constructor(c='ui-textview'){
      super(c),this.clist.add('ui-textview-like')//,this.add(this.view=ce('div','content'));
    }update(text){
      return this.outter.innerText=text,this
    }
  }
  class JSONView extends TextView{
    constructor({options}={}){
      super('ui-jsonview'),this.add(this.view=ce('div','content'));
      this.view.addEventListener('click',e=>{
        for(var n=e.target;!n.classList.contains('object')&&!n.classList.contains('long-string');)
          if(this.outter===(n=n.parentElement))return;
        n.classList.toggle('reduce'),e.stopPropagation();
      });
      this.view.addEventListener('dblclick',e=>{
        for(var n=e.target,w,b;n.$value!=null;)
          if(this.outter===(n=n.parentElement))return;
        w=Win.open(),b=new JSONView({options}),w.inner.appendChild(b.outter),b.update(n.$value);
        e.stopPropagation();
      })
    }update(json){
      //this.outter.innerText=JSON.stringify(json,void 0,2)
      var flat=j=>{
        if(j==null||'object'!==typeof j)
          return o=ce('span',j===null?'null':typeof j),o.$value={value:j},
            (o.innerText='string'!==typeof j?String(j):JSON.stringify(j))
            .length>32&&(o.classList.add('long-string'),o.classList.add('reduce')),o;
        var o=ce('div','object'),f=ce('div','object-frame'),ks;
        f.appendChild(o),Array.isArray(j)&&(o.classList.add('array'),f.classList.add('array-frame'));
        return o.$val={value:j},ks=Object.keys(j),ks.forEach(k=>{
          var kv=ce('div','key-value'),key=ce('span','key'),value=flat(j[k]);
          key.innerText=k,kv.appendChild(key),kv.appendChild(value),o.appendChild(kv)
        }),ks.length>8&&o.classList.add('reduce'),f
      };
      this.view.innerText='';
      this.view.appendChild(flat(json));
      return this
    }
  }
  class NLView extends TextView{
    // constructor0(){
    //   //super('ui-nlview'),this.add(this.view=ce('div','content'))
    // }
  }
  class BookMark extends Block{
    constructor(){
      super('ui-bookmark');
      this.stack=[]
    }push(w){
      w.hide();
      return this.stack.push(w)
    }pop(w){
      var w=this.stack.pop();
      return w.show(),w
    }
  }
  class Workspace extends Content{
    constructor(){
      super('workspace')
    }
  }
  class Input extends Content{
    constructor(c){
      super(c),this.clist.add('ui-input')
    }
  }
  class Setting extends Input{
    constructor(){
      super('ui-setting');
      this.body=ce('textarea','content');
      this.tid=0;
      this.body.addEventListener('change',e=>{
        this.tid||(this.tid=set)
      })
    }open(data,{format,verify}){
      this.data=data;
      this.body.value=JSON.stringify(data);
    }
  }
  class Login extends Input{
    constructor(){
      
    }require(){
      
    }
  }
  class ExpSubmit extends Input{
    constructor(){
      super('exp-submit');
      //this.data={Summary,WorldState,Cover,Description};
    }update(init){
      
    }submit({cover}={}){
      ngapi.submitExp({
        
      })
    }
  }
  class SearchBox extends Input{
    constructor(){
      super('search-box');
    }
  }
  class Desktop extends Block{
    constructor(){
      super('ui-desktop')
    }
  }
  class MessageBox extends Block{
    constructor(){
      super('ui-message-box')
    }
  }
  class Message extends Block{
    
  }
  class Toast extends Message{
    
  }
  class Unfinished extends Content{
    constructor(name){
      super('ui-unfinished');
      this.outter.innerText=`此${name||''}组件未完成`
    }update(){
      return this
    }
  }
  class Launcher extends Block{
    constructor(){
      super('launcher');
    }update(wsp){
      var n=setting.current?.workspace?.launcher?.netlogo
        ,w=JSON.parse(wsp.Workspace);
      if(n)this.outter.innerText='',n.forEach(e=>{
        var b=ce('div','launch-box')
        ,start=e.start
          ?.replace('{scope}',new URL('../..',location))
          .replace('{CacheID}',w.Interfaces['Cache-KeywordID']||null)
          .replace('{LocalID}',wsp.LocalizationID||null)
          .replace('{ID}',wsp.ID||null);
        this.add(b);
        b.innerText=e.description?.join('\n');
        b.onclick=()=>{
          var m=ce('iframe'),w=Win.open();
          m.src=start,m.style='width:100%;height:100%';
          w.inner.appendChild(m);
        }
      })
    }execute(workspace,options){
      fetch()
    }
  }
  var{document,JSON,setTimeout,clearTimeout,setInterval,clearInterval,Object,Array,String}=self,root=new Root,bm=new BookMark,windows={},img_cache={},WinBarFuncArray=[
    {key:'move',text:'M',click:w=>w.freeMove(),iron:''},
    {key:'size',text:'S',click:w=>w.freeResize(),iron:''},
    {key:'min',text:'N',click:w=>(bm.push(w),w.hide()),iron:''},
    {key:'full',text:'F11',click:w=>(document.fullscreen?document.exitFullscreen():w.outter.requestFullscreen()),iron:''},
    {key:'close',text:'X',click:w=>w.close(),iron:'',hoverbg:'#f00'},
  ];
  return{
    img_cache,root,windows,
    Root,Bar,Win,Inner,Content,List,ExpList,CommentTable,CommentArray,ExpInfo,WsInfo,UserInfo,UserItem,UserProject,Item,TagTable,Comment,ExpItem,Background,Img,RichTextBox,TextView,JSONView,NLView,BookMark,Workspace,Input,Login,ExpSubmit,SearchBox,Desktop,MessageBox,Message,Toast
  }
})
/*
summary,description,experiment,discussion,model,comment

*/
