
onmessageerror=console.error

self.addEventListener('message',e=>{
  m=e.data;
  switch(m.action){
    case'show_html':
      document.body.appendChild(Object.assign(document.createElement('div'),m.data));
      return;
    case'exec':
      try{
        var m,t=Date.now(),r=(0,eval)(e.data.code),tag=toString.call(r),time=Date.now()-t;
        try{structuredClone(r)}catch(e){r="can't clone."};
        e.source.postMessage({action:'result',pong:e.data.ping,data:r,tag,time});
      }catch(e){
        e.source.postMessage({action:'error',pong:e.data.ping,data:e&&{
          stack:e.stack,message:e.message
        },tag,time});
      }
  }
});