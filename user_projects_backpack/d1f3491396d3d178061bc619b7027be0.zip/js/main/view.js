document.body.innerText='loadding...'
fetch('/tmp/view').then(r=>(head=r.headers,r.arrayBuffer())).then(b=>{data=new Uint8Array(b)})
.then(()=>{
  var t=head.get('content-type')||'application/bin',n=t.indexOf('/')
    ,img=()=>new Promise((r,j)=>{
      document.body.append(Object.assign(new Image,{
        src:'/tmp/view',style:'width:100vw;margin:0;padding:0',
        onload:r,onerror:j
      }))
    }),bin=()=>new Promise((r,j)=>{
      
    })
  switch(t.slice(0,n)){
    case'text/plain':
      document.body.innerText=new TextDecoder().decode(data);break;
    case'text/json':
    case'application/json':
      document.body.innerText=new TextDecoder().decode(data);break;
    case'image/png':
    case'image/jpg':
    case'image/jpeg':
    case'image/gif':
    case'image/svg+xml':
    case'image/webp':
      img().catch(bin)
      break;
  }
})
