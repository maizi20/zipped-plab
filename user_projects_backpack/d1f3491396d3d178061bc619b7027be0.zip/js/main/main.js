import('../lib/define.js')
//.then(()=>AMD.amd.loadScript())
.then(()=>{
  AMD.define('promise',[],P=>Promise);
  AMD.define('req',[],()=>o=>fetch(o.url,o));
  AMD.define(
    'local_data',['lpromise','req','flat_json','lzstring']
    ,(P,q,f,l)=>P.all([
      q({url:'/user_projects_assets/des.bin'}).then(r=>r.arrayBuffer())
      .then(b=>l.decompressFromUint8Array(new Uint8Array(b)).split('\r'))
      ,q({url:'/user_projects_assets/exp.bin'}).then(r=>r.arrayBuffer())
      .then(b=>f.parse(JSON.parse(l.decompressFromUint8Array(new Uint8Array(b)))))
      ,q({url:'/user_projects_assets/comment.bin'}).then(r=>r.arrayBuffer())
      .then(b=>f.parse(JSON.parse(l.decompressFromUint8Array(new Uint8Array(b)))))
    ]).then(a=>{
      console.log(a);
      return a
    })
  );
  AMD.define('setting',[],()=>fetch('../../page/info/settings.json').then(r=>r.json()).then(o=>o));
  AMD.define('login',[],()=>({}));
  AMD.define('api',['API','setting'],(c,setting)=>(
    c=new c,c.tryLogin(setting.current.api.login.current)
  ));
  AMD.define('main',['req','api','ui','setting'],async function(req,ngapi,ui,setting){
    //onbeforeunload=e=>e.preventDefault();
    var w=ui.Win.open({rect:[0,0,800,800]}),el=new ui.ExpList();
    top.win=w;
    w.goto('experiments:Skip/0/Take/20/UserID/60dc6b7104a1226aa18c6482');
    //open(setting.current?.api?.proxy?.url);
    //w.goto('experiment:6640deae65678c5f38052043');
  });
  return AMD.import([
    '../../js/main/api.js','../../js/main/ui.js','../../js/lib/lib.js'
  ],u=>new Promise((r,j)=>{
    var e=document.createElement('script');
    e.src=u,e.charset='UTF8',e.onload=r,e.onerror=j,document.head.appendChild(e)
  }))
}).then(()=>AMD.require(['main'])).then(console.log)
