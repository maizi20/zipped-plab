var cnt=e=>{
  console.log('working...');
  if(!opener&&!e.source)return;
  var{port1,port2}=new MessageChannel,map={};
  port1.onmessage=e=>{
    e=e.data;
    switch(e.action){
      case'ping':
        return e.action='pong',port1.postMessage(e,e.tr||[]);
      case'abort':
        return map[e.ping]?.abort(),delete map[e.ping];
      case'req':
        return port1.postMessage({action:'pong',pong:e.ping}),e.signal=(map[e.ping]=new AbortController).signal,
        fetch(e.url,e).then(r=>r.arrayBuffer().then(
          b=>port1.postMessage({action:'res',pong:e.ping,body:b,headers:[...r.headers],status:r.status})
        )).catch(n=>port1.postMessage({action:'err',pong:e.ping,error:''+n}))
        .finally(()=>delete map[e.ping]);
    }
  };
  (opener||e.source).postMessage({action:'port',port:port2,url:location.href,tr:[port2]},'*',[port2]);
  document.title='working...'
};
self.addEventListener('message',e=>{
  var m=e.data;
  if(m.action==='ready')
    e.source.postMessage({action:'exec',code:cnt+'\n//# source'+'URL=port.js'},'*');
  else if(m.action==='port')
    m.action='port_proxy',navigator.serviceWorker.controller.postMessage(m,m.tr||[]);
});
//open('https://nlm-api-cn.turtlesim.com/Users?mode=deb.html');
