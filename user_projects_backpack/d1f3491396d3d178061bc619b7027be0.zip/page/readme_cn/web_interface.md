[返回](#index.md)
以下是关于对Workspace中的Interfaces.Web字段的使用，未实装

使用了网页端的实验将会在Workspace中的Interfaces.Web字段添加一个JSON对象
实验内无法直接读取此字段，但可以在存档中找到此部分内容

Manifest

以下字段将对应网页端部分特有功能：
## Version
数字，描述了Manifest字段的版本

## Permissions
列表，运行此实验必须的权限

## Description
字符串或列表，简介

## Sign
列表，提供管理人员的数字签名以使用受限制的功能

## Author
对象，发布者的简要信息，包含以下字段：(更多信息可以通过ID指定到Coauthors字段中)
### NickName
字符串，发布者的昵称
### ID
字符串，发布者的昵称
### Authorisation

### Coauthors
列表，可包含多个合作者或管理人员的信息，每个合作者包含以下字段：
#### ID
字符串，合作者的昵称
#### NickName
字符串，合作者的昵称
#### Description
#### Task
字符串，合作者的任务简述
#### Sign
合作者的签名，管理人员在此字段中授权受限制的功能



## Source
列表，使用资源

...
