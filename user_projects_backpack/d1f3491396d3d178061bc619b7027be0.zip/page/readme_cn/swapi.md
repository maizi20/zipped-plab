
#作用域(scope)
ServiceWorker只能接管在作用域范围内的页面的大部分请求
不包括主线程的同步XHR

#网络白名单
可以正常请求:
https://zhishi.oss-cn-beijing.aliyuncs.com/user_projects_backpack/目录下的所有内容

仅在200-299响应状态时可用：
turtlesim.com,aliyuncs.com,github.io,netlogoweb.org及其子域名

仅能使用GET方法，隐藏Referre标头并且会自动缓存响应：
netlogo-cn.oss-cn-hongkong.aliyuncs.com
physics-lab.oss-cn-hongkong.aliyuncs.com
netlogo-static-cn.turtlesim.com
physics-static-cn.turtlesim.com



#虚拟目录
以下内容存在sw缓存中，均无法直接通过网络访问对应的路径得到
如无特殊声明，HTML页面和作为worker的JS脚本和大部分文件均存在于相对于作用域两层目录深度的位置，方便相对引用到正确的文件
ServiceWorker是例外，因为ServiceWorker的作用域必须完全处于自己的目录内

##js
存储和引用脚本

##page
大部分页面都通过此目录访问
###format
页面的模板，正常情况下不会访问到
###info
修改和保存设置和其它信息的目录
###readme_cn
中文文档
###main
主页面

##assets
存储了大部分素材
~可以通过简写ass访问~
###img
图片
###json
json

#api
