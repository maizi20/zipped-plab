#已使用的第三方库
{scope}/js/lib/crypto_js.min.js
仓库名：crypto-js
一个前端加密库
用途：
ServiceWorker生成文件MD5

{scope}/js/lib/json5.min.js
仓库名：JSON5
更易于人类阅读的JSON格式解析器
用途：
修改可以加注释的设置

{scope}/js/lib/jszip.min.js
仓库名：JSZip
可以用前端和Node.js，海实V8加个setTimeout也能用的Zip包压缩和解压库
用途：
打包此项目和模型引擎，减少总体积和请求次数

{scope}/js/lib/marked.min.js
仓库名：marked
Markdown 解析器和编译器
用途：
主页和(未实装的)unity富文本标签中的MD标签

{scope}/js/lib/lzstring.min.js
仓库名：LZString
非常小的字符串压缩库
用途：解码海实的世界状态码

#未实装的库


