

[浏览实验](../../page/main/desktop.html)
在这里访问已经打包好的社区内容，如果已接入社区API可访问社区内容

[修改设置](../../page/info/pwa.html)
横杠结尾的字段不会被使用
支持以JSON5格式修改JSON，但未来可能加上自动更新，自动转换JSON会移除JSON5的注释和特殊格式

[接入社区API](../cors/index.html)

[设置渐进式应用](../../page/info/pwa.html)
支持以JSON5格式修改JSON
听说iOS的渐进式应用程序支持通知功能了

[swAPI概述](#swapi.md)
基于ServiceWorker实现的，不完全依赖网络的接口

[关于富文本标签](#rich_text.md)

[网页端实验接口标注](#web_interface.md)
关于网页端特有功能的一些规划

[模型引擎](#engine.md)
关于加载NetLogo和NetTango模型的引擎

[下载项目压缩包](/user_projects_backpack/d1f3491396d3d178061bc619b7027be0.zip)
使用jszip生成的项目压缩包，其中jszip.min.js位于所有文件中的第一个并且使用原文存储以便直接从压缩包中截取为解压脚本

[加密](#crypto.md)
还没做

[引用](#reference.md)
使用的代码库以及模型引擎

