[返回](#index.md)

缓存设置
# everything
任何未被设置的值均采用此值

# experiment
实验区作品
## experiment_summary
实验信息，不包含简介
## experiment_description
实验简介
## experiment_comment
实验评论

# discussion
交流区作品
## discussion_summary
交流信息，不包含简介
## discussion_description
交流简介
## discussion_comment
交流评论

# model
模型区作品
## model_summary
模型信息，不包含简介
## model_description
模型简介
## model_comment
模型评论

# workspace
工作空间
## workspace_summary
工作空间对应的作品
## workspace_external
工作空间的外部内容
### workspace_external_library
工作空间的外部库
### workspace_external_polyfill
工作空间的外部polyfill
## workspace_internal
工作空间的内部内容
### workspace_internal_module
工作空间的netlogo代码
### workspace_internal_tutorial
工作空间的教程
### workspace_internal_localization
工作空间的翻译

# user
用户
# user_comment
用户留言板
# user_statistic
用户详细信息(精选数,金币数,封面实验等)

# self
自己
## self_comment
自己的主页
## self_statistic
自己的详细信息
## self_info
自己的个人资料









